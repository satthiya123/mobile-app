package com.example.project_app

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
